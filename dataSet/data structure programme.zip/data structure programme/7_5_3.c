#include <stdio.h>
#include <stdlib.h>
/*邻接表存储结构*/
#define NumEdges 7//边条数
#define NumVertices 6//顶点个数
typedef char VertexData;//顶点数据类型
typedef int EdgeData;//边上权值类型
typedef struct node{//边表中的结点类型
int adjvex;//邻接点下标
EdgeData cost;//边上权值
struct node *next;//指向下一边
}EdgeNode;
typedef struct{//顶点表的结点类型
int inDegree;
VertexData vertex;//顶点数据信息域
EdgeNode *firstedge;//边链表的头结点
}VertexNode,AdjList[NumVertices];
typedef struct{//图的邻接表
AdjList vexlist;
int n,e;//图中当前的顶点个数与边数
}AdjGragh,*GraphAdjList;

//基本操作

/*创建图的邻接表*/
void CreateAdjGragh(AdjGragh *G)
{
char c[NumVertices]={'1','2','3','4','5','6'};
int a[NumEdges]={0,0,1,2,2,3,4};
int b[NumEdges]={3,1,5,3,0,4,1};
int inD[6]={0,2,0,2,1,1};
int i,head,tail,weight;
G->n=NumVertices;//顶点个数
G->e=NumEdges;//边数
for(i=0;i<G->n;i++)
{
G->vexlist[i].inDegree=inD[i];
}
for(i=0;i<G->n;i++)
{
G->vexlist[i].vertex=c[i];//顶点信息
G->vexlist[i].firstedge=NULL;//边表置为空表
}
for(i=0;i<G->e;i++)//边
{
EdgeNode *p=(EdgeNode *)malloc(sizeof(EdgeNode));
p->adjvex=b[i];
p->next=G->vexlist[a[i]].firstedge;
G->vexlist[a[i]].firstedge=p;
}
}

//输出邻接表
void DispAdjGragh(AdjGragh *G)
{
int i,j;
EdgeNode *p=(EdgeNode *)malloc(sizeof(EdgeNode));
for(i=0;i<G->n;i++)
{
printf("%d:",i);
p=G->vexlist[i].firstedge;
while(p!=NULL)
{
printf("%d ",p->adjvex);
p=p->next;
}
printf("\n");
}
}

//拓扑排序,需要使用辅助栈结构，用于存储入度为0的结点
void TopSort(AdjGragh *G)
{
EdgeNode *e;
int t=0;
int c=0;
int *s=(int*)malloc(G->n*sizeof(int));;//用于保存入度为0的结点
int i,k,top;
for(i=0;i<G->n;i++)//遍历寻找入度为0的结点
{
if(G->vexlist[i].inDegree==0)
s[++t]=i;
}
while(t!=0)//栈不为空
{
top=s[t];
t--;
printf("%c ",G->vexlist[top].vertex);
c++;
for(e=G->vexlist[top].firstedge;e;e=e->next)
{
k=e->adjvex;
if((--G->vexlist[k].inDegree)==0)//入度减一，若为0，则入栈
{
t=t+1;
s[t]=k;
}
}
}
}

//主函数
void main()
{

AdjGragh *G=(AdjGragh *)malloc(sizeof(AdjGragh));
CreateAdjGragh(G);
DispAdjGragh(G);
printf("拓扑排序序列为：");
TopSort(G);
}
