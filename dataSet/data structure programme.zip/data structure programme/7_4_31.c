#include <stdio.h>
#include <malloc.h>
/*图的深度优先遍历*/
/*邻接矩阵存储结构*/
#define NumEdges 11//边条数
#define NumVertices 6//顶点个数
int visited[NumVertices]={0,0,0,0,0,0};//设置一个全局标志数组visited[NumVertices]来标志某个顶点是否被访问过。
char c[NumVertices]={'1','2','3','4','5','6'};
typedef char VertexData;//顶点数据类型
typedef int EdgeData;//权值类型
typedef struct{
    VertexData vexlist[NumVertices];//顶点表
    EdgeData edge[NumVertices][NumVertices];//边表即邻接矩阵
    int n,e;//图中当前顶点个数与边数
}MGraph;

//基本操作

/*创建图的邻接矩阵*/
void CreateMGraph(MGraph *G)
{
    int i,j;
    int a[NumVertices][NumVertices]={{0,0,0,0,0,0},{1,0,0,1,0,0,0},{0,1,0,0,0,0,1},{0,0,1,0,1,1},{1,0,0,0,0,0},{1,1,0,0,1,0,1}};
    G->n=NumVertices;//顶点数
    G->e=NumEdges;//边数
    for(i=0;i<G->n;i++)//建立顶点表
        G->vexlist[i]=c[i];
    for(i=0;i<G->n;i++)//邻接矩阵的初始化
        for(j=0;j<G->n;j++)
            G->edge[i][j]=a[i][j];
}

//输出邻接矩阵
void DispMGraph(MGraph *G)
{
    int i,j;
    for(i=0;i<G->n;i++)
        {
            for(j=0;j<G->n;j++)
                printf("%d ",G->edge[i][j]);
            printf("\n");
        }
}
//访问函数
void visit(int i)
{
    printf("%c ",c[i]);
}

/*用邻接矩阵实现图的深度优先遍历*/
void DFS(MGraph *G,int i)
{
    int j;
    visit(i);//输出访问结点，该部分可为printf("%d",i);
    visited[i]=1;//置全局变量标志
    for(j=0;j<G->n;j++)
        if((G->edge[i][j]==1)&&(!visited[j]))
            DFS(G,j);
}

//主函数
void main()
{
    MGraph *G=(MGraph *)malloc(sizeof(MGraph));
    CreateMGraph(G);
    printf("图的邻接矩阵为：\n");
    DispMGraph(G);
    printf("图的深度优先遍历序列为（邻接矩阵存储结构）：");
    DFS(G,0);
    printf("\n");

}

