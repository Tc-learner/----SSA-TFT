#include <stdio.h>
#include <stdlib.h>
/*邻接矩阵存储结构*/
#define NumEdges 10//边条数
#define NumVertices 6//顶点个数
#define INF 100//定义无穷大

#define MaxSize 100
typedef char VertexData;//顶点数据类型
typedef float EdgeData;//权值类型
typedef struct{
    VertexData vexlist[NumVertices];//顶点表
    EdgeData edge[NumVertices][NumVertices];//边表即邻接矩阵
    int n,e;//图中当前顶点个数与边数
}MGraph;
typedef struct
{
    int x;//起始顶点
    int y;//终止顶点
    float w;//权值
}Edge;
char c[NumVertices]={'1','2','3','4','5','6'};
/*创建图的邻接矩阵*/
void CreateMGraph(MGraph *G)
{
    int i,j;
    float a[NumVertices][NumVertices]={{INF,0.6,0.1,0.5,INF,INF},{0.6,INF,0.5,INF,0.3,INF},{0.1,0.5,INF,0.5,0.6,0.4},{0.5,INF,0.5,INF,INF,0.2},{INF,0.3,0.6,INF,INF,0.6},{INF,INF,0.4,0.2,0.6,INF}};//不妨将权值设为Q_ij=(〖Delay〗_ij*〖Lost〗_ij*〖Cost〗_ij)/〖BandWidth〗_ij
    G->n=NumVertices;//顶点数
    G->e=NumEdges;//边数
    for(i=0;i<G->n;i++)//建立顶点表
        G->vexlist[i]=c[i];
    for(i=0;i<G->n;i++)//邻接矩阵的初始化
        for(j=0;j<G->n;j++)
            G->edge[i][j]=a[i][j];
}
void DispMGraph(MGraph *G)//输出邻接矩阵
{
    int i,j;
    for(i=0;i<G->n;i++)//邻接矩阵的输出
        {
            for(j=0;j<G->n;j++)
                printf("%f ",G->edge[i][j]);
            printf("\n");
        }
}
void Sort(Edge E[],int n)//排序
{
    int p,q;
    Edge t;
    for(p=1;p<n;p++)
    {
        t=E[p];
        q=p-1;
        while(q>=0&&t.w<E[q].w)
        {
            E[q+1]=E[q];
            q--;
        }
        E[q+1]=t;
    }
}
/*普里姆算法*/
void Prim(MGraph *G)
{
    int i,j,k;
    float min;
    float lowcost[NumVertices];//保存相关顶点间边的权值
    int adjvex[NumVertices];//保存相关顶点下标
    adjvex[0]=0;
    lowcost[0]=0;
    for(i=1;i<G->n;i++)//置初值
    {
        lowcost[i]=G->edge[0][i];
        adjvex[i]=0;
    }
    for(i=1;i<G->n;i++)//找n-1个顶点
    {
        min=INF;
        k=0;
        for(j=1;j<G->n;j++)//在V-U中找出离U最近顶点
            if(lowcost[j]!=0&&lowcost[j]<min)
            {
                min=lowcost[j];
                k=j;
            }
        printf("(%c,%c):%f\n",c[adjvex[k]],c[k],min);
        lowcost[k]=0;
        for(j=1;j<G->n;j++)//更新数组
            if(lowcost[j]!=0&&G->edge[k][j]<lowcost[j])
            {
                lowcost[j]=G->edge[k][j];
                adjvex[j]=k;
            }
    }
}
void main()
{
    MGraph *G=(MGraph *)malloc(sizeof(MGraph));
    CreateMGraph(G);
    DispMGraph(G);
    printf("生成树的克鲁斯卡尔算法：\n");
    Kruskal(G);
}
