#include<stdio.h>
int maxterm=12,maxclass=100;   //学期上限12，课程最大100
int allterm,maxxf,num;            //学期总数 学分上限 课程数
int Graph[100][100]={0};       //邻接矩阵;
int indegree[100]={0};         //入度矩阵
int visit[100]={0};            //visit数组
int Q[100];                    //临时队列
int end=0,top=0;               //队列头尾
int over[100]={0};             //排完的课程
 
typedef struct class
{
    char name[3];
    int xf;
}class,*pclass;

class CLASS[100];
void creat()        //图的创建
{
    int i,v;
    char a;
    scanf("%d",&allterm);
    scanf("%d",&maxxf);
    scanf("%d",&num);
    for(i=0;i<num;i++)
    {
        scanf("%s",CLASS[i].name);
        scanf("%d",&CLASS[i].xf);
        while((a=getchar())!='\n')
        {
            a=getchar();
            scanf("%d",&v);
            Graph[v-1][i]=1;
            indegree[i]++;
        }
    }
}

void display()       //画出邻接矩阵
{
    int i,j;
    printf("————邻接矩阵————\n") ;
    for(i=0;i<num;i++)
    {
        for(j=0;j<num;j++)
        {
            printf("%d%c",Graph[i][j],j==num-1?'\n':' ');
        }
    }
    printf("—————————————\n") ;
}

int front()
{
    return Q[top];
}
void push(int i)
{
    Q[end++]=i;
}

void pop()
{
    top++;
}

int empty()
{
    if(top==end)
        return 1;
    else
        return 0;
}
void top_sort()
{
    int i,j,V,count=0;
    for(i=0;i<num;i++)
    {
        if(indegree[i]==0)
            push(i);
    }
    while(!empty())
    {
        V=front();
        over[count++]=V;
        visit[V]=1;
        pop();
        for(j=0;j<num;j++)
        {
            if(Graph[V][j]==1)
            {
                indegree[j]--;
                if(indegree[j]==0)
                    push(j);
            }
        }
    }
    for(i=0;i<num;i++)
    {
        if(visit[i]==0)
            printf("课程存在错误\n");
            break;
    }
}

void solve1()
{
    int i,j,one_term,more,mark=0;
    one_term=num/allterm;
    more=num%allterm;
    for(i=0;i<more;i++)
    {
        printf("第%d个学期课程安排:",i+1);
        for(j=0;j<one_term+1;j++)
        {
            printf("%s ",CLASS[over[j+i*(one_term+1)]].name);
        }
        putchar('\n');
    }
    mark=more*(one_term+1)-1;
    for(i;i<allterm;i++)
    {
        printf("第%d个学期课程安排:",i+1);
        for(j=0;j<one_term;j++)
        {
            printf("%s ",CLASS[over[more+j+i*one_term]].name);
        }
        putchar('\n');
    }
}

void solve2()
{
    int i=1,j=0,total;
    while(i<=allterm)
    {
        total=0;
        printf("第%d个学期课程安排:",i);
        while(total<=10 && j<num)
        {
            total+=CLASS[over[j]].xf;
            if(total<=maxxf)
            {
                printf("%s ",CLASS[over[j]].name);
            }
            j++;
        }
        putchar('\n');
        j--;
        i++;
    }
    
}

int main()
{
    int i,j,solve;
    creat();
    display();
    top_sort();
    printf("平均安排输出1，密集安排输入2：");
    scanf("%d",&solve);
    if(solve==1)
        solve1();
    else
        solve2();
    return 0;
}

/*
