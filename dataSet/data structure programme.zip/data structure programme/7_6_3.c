#include <stdio.h>
#include <stdlib.h>
 
#define bool char
#define true 1
#define false 0
#define MaxSize 10000
/****************队列结构*******************/
typedef struct Node
{
    int step;
    int cur;
}Node;
 
typedef struct Queue
{
    Node *data;
    int front;
    int rear;
}Queue;
//初始化
bool InitQueue(Queue* Q)
{
    Q->front = Q->rear = 0;
    Q->data = (Node*)malloc(sizeof(Node)*MaxSize);
    return true;
}
 
//入队
bool EnQueue(Queue* Q, Node e)
{
    if((Q->rear+1)%MaxSize == Q->front) return false;
    Q->data[Q->rear] = e;
    Q->rear = (Q->rear+1)%MaxSize;
 
    return true;
}

//出队
bool DeQueue(Queue* Q, Node* e)
{
    if(Q->rear == Q->front) return false;
    *e = Q->data[Q->front];
    Q->front = (Q->front+1)%MaxSize;
    return true;
}
 
//打印队列元素
bool PrintQueue(Queue Q)
{
    for(int i = 0; i < (Q.rear-Q.front+MaxSize)%MaxSize; i++)
    {
        if(i == 0)
            printf("%d", Q.data[i].cur);
        else
            printf(" %d", Q.data[i].cur);
    }
    return true;
}
/****************邻接表结构*******************/

//定义邻接图的节点
typedef struct ArcNode
{
    //结点名
    int name;
    //下一个结点
    struct ArcNode *next;
    //该节点是否被选中过
    int info;
}ArcNode;

//定义邻接图结构
typedef struct Grape
{
    //顶点的信息
    int data;
    //顶点所能到达结点的集合
    ArcNode *first;
}VNode, List[MaxSize];//所有顶点都包含
 
//邻接表
typedef struct
{
    List LinJie;
    int n, m;
}ALGraph;
 
//创建邻接表
bool CreateUDG(ALGraph* G, int n, int m)
{
    int i, j, k;
    //先输入总顶点数和总边数
    G->n = n;
    G->m = m;
    //scanf("%d %d", &G->n, &G->m);
    //输入顶点值(从下表1开始存储的)
    for(i = 1; i <= G->n; i++)
    {
        //每个顶点
        G->LinJie[i].data = i;
        //初始化头结点指针为NULL
        G->LinJie[i].first = NULL;
    }
    //输入各边，构造邻接矩阵
    for(k = 0; k < G->m; k++)
    {
        //每条边依附的两个点
        int v1, v2;
        scanf("%d %d", &v1, &v2);
        //确定v1和v2所在顶点的位置
        i = v1; j = v2;
        //生成一个新的边节点
        ArcNode* p1 = (ArcNode*)malloc(sizeof(ArcNode));
        p1->name = j;
 
        //把新节点插入头部
        p1->next = G->LinJie[i].first;
        G->LinJie[i].first = p1;
 
        //生成一个新的边节点
        ArcNode* p2 = (ArcNode*)malloc(sizeof(ArcNode));
        p2->name = i;
 
        //把新节点插入头部
        p2->next = G->LinJie[j].first;
        G->LinJie[j].first = p2;
    }
    return true;
}
 
//遍历图
bool Print(ALGraph G, int n)
{
    int i = 0;
    for(i = 1; i <= n; i++)
    {
        //输出顶点名
        printf("%d：",G.LinJie[i].data);
        ArcNode* p = G.LinJie[i].first;
        while(p)
        {
            printf("%d->", p->name);
            p = p->next;
        }
        printf("\n");
    }
    return true;
}
 
//广度优先遍历
int BFS(ALGraph* G, int v)
{
    Node st,pt,curq;
    st.cur = v;
    st.step = 0;
    int c = 1;
    //先让判断是否选中的数组都等于零
    bool visited[MaxSize] = {0};
    //临时遍历u用来放当前结点值，
    int u;
    //搞一个队列用来输出
    Queue Q;
    InitQueue(&Q);
    //出发点先弄上
    visited[v] = true;
    EnQueue(&Q, st);
    //一个临时存放邻接表结点
    ArcNode* p;
    while(QueueLength(Q))
    {
        DeQueue(&Q, &curq);
 
        //printf("%d->",curq.cur);
        if(curq.step == 6) break;
 
        p = G->LinJie[curq.cur].first;
 
        while(p)
        {
            pt.step = curq.step;
            pt.cur = p->name;
            if(!visited[p->name])
            {
                c++;
                pt.step++;
                EnQueue(&Q, pt);
                visited[p->name] = true;
            }
            p = p->next;
        }
    }
    return c;
}
 
int main()
{
    ALGraph G;
    int n, m;
    scanf("%d %d",&n,&m);
    CreateUDG(&G, n, m);
 
    //Print(G, 10); //测试用遍历
    //printf("\n");
    for(int i = 1; i <= n; i++)
    {
        float s;
 
        s = BFS(&G, i);
 
        printf("%d: %.2f%%\n", i, s/n*100);
    }
    return 0;
}
