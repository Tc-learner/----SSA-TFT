#include <stdio.h>
#include <malloc.h>
/*图的深度优先遍历*/
/*邻接表存储结构*/
#define NumEdges 11//边条数
#define NumVertices 6//顶点个数
int visited[NumVertices]={0,0,0,0,0,0};//设置一个全局标志数组visited[NumVertices]来标志某个顶点是否被访问过。
char c[NumVertices]={'1','2','3','4','5','6'};
typedef char VertexData;//顶点数据类型
typedef int EdgeData;//边上权值类型
typedef struct node{//边表中的结点类型
    int adjvex;//邻接点下标
    EdgeData cost;//边上权值
    struct node *next;//指向下一边
}EdgeNode;
typedef struct{//顶点表的结点类型
    VertexData vertex;//顶点数据信息域
    EdgeNode *firstedge;//边链表的头结点
}VertexNode;
typedef struct{//图的邻接表
    VertexNode vexlist[NumVertices];
    int n,e;//图中当前的顶点个数与边数
}AdjGragh;

//基本操作

/*创建图的邻接表*/
void CreateAdjGragh(AdjGragh *G)
{
    char c[NumVertices]={'1','2','3','4','5','6''};
    int a[NumEdges]={1,1,2,2,3,3,3,4,5,5,5};
    int b[NumEdges]={0,3,1,5,2,4,5,0,0,1,4 };
    int i,head,tail,weight;
    G->n=NumVertices;//顶点个数
    G->e=NumEdges;//边数
    for(i=0;i<G->n;i++)
    {
        G->vexlist[i].vertex=c[i];//顶点信息
        G->vexlist[i].firstedge=NULL;//边表置为空表
    }
    for(i=0;i<G->e;i++)//边
    {
        EdgeNode *p=(EdgeNode *)malloc(sizeof(EdgeNode));
        p->adjvex=b[i];
        p->next=G->vexlist[a[i]].firstedge;
        G->vexlist[a[i]].firstedge=p;
    }
}

//访问函数
void visit(int i)
{
    printf("%c ",c[i]);
}

/*用邻接表实现图的深度优先搜索*/
void DFS(AdjGragh *G,int i)
{
    EdgeNode *p;
    visit(i);//输出访问结点
    visited[i]=1;//置全局变量标志
    for(p=G->vexlist[i].firstedge;p!=NULL;p=p->next)
    {
        if(!visited[p->adjvex])
            DFS(G,p->adjvex);
    }
}

//主函数
void main()
{
    AdjGragh *G=(AdjGragh *)malloc(sizeof(AdjGragh));
    CreateAdjGragh(G);
    printf("\n");
    printf("\n");
    printf("图的深度优先遍历序列为（邻接表存储结构）：");
    DFS(G,0);
    printf("\n");
    printf("\n");
    printf("\n");
}
